
import gym
import numpy as np

class TrafficEnv(gym.Env):
    def __init__(self):
        super(TrafficEnv, self).__init__()
        self.observation_space = gym.spaces.Box(low=0, high=100, shape=(4,), dtype=np.float32)
        self.action_space = gym.spaces.Discrete(2)
        self.state = np.zeros(4)

    def reset(self):
        self.state = np.random.randint(0, 10, size=(4,))
        return self.state

    def step(self, action):
        reward = -np.sum(self.state)
        self.state = np.random.randint(0, 10, size=(4,))
        done = np.random.rand() > 0.95
        return self.state, reward, done, {}
