#!/bin/bash
python train.py
