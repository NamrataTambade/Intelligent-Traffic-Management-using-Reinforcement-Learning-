
from traffic_env import TrafficEnv
from dqn_agent import DQNAgent
import numpy as np

env = TrafficEnv()
state_size = env.observation_space.shape[0]
action_size = env.action_space.n
agent = DQNAgent(state_size, action_size)

agent.epsilon = 0.0
state = env.reset()
state = np.reshape(state, [1, state_size])
total_reward = 0
for time in range(500):
    action = agent.act(state[0])
    next_state, reward, done, _ = env.step(action)
    state = np.reshape(next_state, [1, state_size])
    total_reward += reward
    if done:
        break
print(f"Total Reward: {total_reward}")
